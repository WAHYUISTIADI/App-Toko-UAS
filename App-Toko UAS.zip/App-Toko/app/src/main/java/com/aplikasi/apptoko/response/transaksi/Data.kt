package com.aplikasi.apptoko.response.transaksi

data class Data(
    val transaksi: List<Transaksi>,
    val total:String
)